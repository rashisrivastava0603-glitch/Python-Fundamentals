cube= lambda x: x**3
print(cube(3))

square=lambda y: y**2
print(square(4))

import math
Area_of_circle = lambda r:  math.pi*r**2
print (Area_of_circle(2))

import math
Circumference_of_circle = lambda r: 2*math.pi*r
print(Circumference_of_circle(4))