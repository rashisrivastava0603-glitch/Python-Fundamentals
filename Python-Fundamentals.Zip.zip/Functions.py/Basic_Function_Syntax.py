def square(num):
    return num**2
num= int(input("Enter a number:"))
print(square(num))
