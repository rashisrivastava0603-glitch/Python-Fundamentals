def add(num1,num2):
    return num1+num2
num1=int(input("Enter a number:"))
num2=int(input("Enter a number:"))
print(add(num1,num2))