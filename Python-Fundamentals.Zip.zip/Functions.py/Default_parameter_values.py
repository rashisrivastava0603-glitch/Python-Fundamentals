def greet(name="Username"):
    return "Hello,"+ name + "!"
print(greet("Dosto"))