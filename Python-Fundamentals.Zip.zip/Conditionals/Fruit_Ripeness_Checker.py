fruit=input(("Enter the fruit:"))
color=input(("Enter the color:"))
if(color=="green"):
   if(fruit=="Banana"):
    print("Unripe")
elif(color=="yellow"):
    print("Ripe")
elif(color=="Brown"):
    print("Overripe")
    
