weather=input(("Todays_Weather:"))
if(weather == "sunny"):
    activity=("Go for a walk")
    print(activity)
elif(weather == "Rainy"):
    activity=("Read a book")
    print(activity)
elif(weather=="Snowy"):
    activity=("Build a snowman")
    print(activity)

