Age= int(input("Enter Age:"))
if(Age<13):
    print("child")
elif(Age<20):
    print("Teenager")
elif(20<Age<60):
    print("Adult")
elif(Age>60):
    print("Senior")

