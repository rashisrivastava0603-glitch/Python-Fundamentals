String=("python")
reversed_string=""
for char in String:
    reversed_string= char + reversed_string
    print(reversed_string)