n=int(input("Enter a number:"))
table=0
for i in range(1,11):
    if(i>0,i*n):
        table+=1
    if(i==5):
        continue
        print(n,"x",i,"=",i*n)
