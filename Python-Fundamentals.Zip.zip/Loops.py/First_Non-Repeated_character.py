Character=("rashisrivastava")
for char in Character:
   if Character.count(char)==1:
    print(char)
